class Local {
  final String cidade;
  final String nome;
  final String imagemUrl;
  final String descricao;

  const Local({
    required this.cidade,
    required this.nome,
    required this.imagemUrl,
    required this.descricao,
  });
}
