import 'package:flutter/material.dart';
import '../models/local.dart';

class CabecalhoLocal extends StatelessWidget {
  final Local local;

  const CabecalhoLocal({super.key, required this.local});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Image.network(
          local.imagemUrl,
          width: double.infinity,
          height: 220,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) => Container(
            height: 220,
            color: Colors.grey.shade300,
            child: const Icon(Icons.broken_image, size: 48),
          ),
        ),
        Positioned(
          left: 12,
          bottom: 10,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(local.cidade,
                  style: const TextStyle(color: Colors.white, fontSize: 12)),
              Text(local.nome,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ],
    );
  }
}
