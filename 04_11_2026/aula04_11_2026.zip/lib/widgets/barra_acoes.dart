import 'package:flutter/material.dart';
import 'botao_acao.dart';

class BarraAcoes extends StatelessWidget {
  final bool queroIr;
  final bool jaFui;
  final VoidCallback onQueroIr;
  final VoidCallback onJaFui;
  final VoidCallback onCompartilhar;
  final VoidCallback onAvaliacoes;

  const BarraAcoes({
    super.key,
    required this.queroIr,
    required this.jaFui,
    required this.onQueroIr,
    required this.onJaFui,
    required this.onCompartilhar,
    required this.onAvaliacoes,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          BotaoAcao(
            icone: const Icon(Icons.place),
            texto: 'Quero Ir',
            selecionado: queroIr,
            onTap: onQueroIr,
          ),
          BotaoAcao(
            icone: const Icon(Icons.check_circle_outline),
            texto: 'Já Fui',
            selecionado: jaFui,
            onTap: onJaFui,
          ),
          BotaoAcao(
            icone: const Icon(Icons.share),
            texto: 'Compartilhar',
            onTap: onCompartilhar,
          ),
          BotaoAcao(
            icone: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(3, (_) => const Icon(Icons.star)),
            ),
            texto: 'Avaliações',
            onTap: onAvaliacoes,
          ),
        ],
      ),
    );
  }
}
