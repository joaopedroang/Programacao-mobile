import 'package:flutter/material.dart';

class BotaoAcao extends StatelessWidget {
  final Widget icone;
  final String texto;
  final VoidCallback? onTap;
  final bool selecionado;

  const BotaoAcao({
    super.key,
    required this.icone,
    required this.texto,
    this.onTap,
    this.selecionado = false,
  });

  @override
  Widget build(BuildContext context) {
    final cor = selecionado ? Colors.green : Colors.blue;

    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconTheme(data: IconThemeData(color: cor), child: icone),
            const SizedBox(height: 4),
            Text(texto, style: TextStyle(color: cor, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
