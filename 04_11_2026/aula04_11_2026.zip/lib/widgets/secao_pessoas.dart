import 'package:flutter/material.dart';
import 'botao_acao.dart';

class SecaoPessoas extends StatelessWidget {
  final int quantidade;
  final VoidCallback onFiltrar;

  const SecaoPessoas({
    super.key,
    this.quantidade = 4,
    required this.onFiltrar,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              const Text(
                'Pessoas Encontradas',
                style: TextStyle(
                    color: Colors.blue,
                    fontSize: 18,
                    fontWeight: FontWeight.bold),
              ),
              BotaoAcao(
                icone: const Icon(Icons.filter_alt),
                texto: 'Filtrar',
                onTap: onFiltrar,
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(
              quantidade,
              (_) => CircleAvatar(
                radius: 28,
                backgroundColor: Colors.grey.shade300,
                child: const Icon(Icons.person, size: 40, color: Colors.grey),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
