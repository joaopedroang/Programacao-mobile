import 'package:flutter/material.dart';
import '../models/local.dart';

class TelaAvaliacoes extends StatelessWidget {
  final Local local;

  const TelaAvaliacoes({super.key, required this.local});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Avaliações - ${local.nome}')),
      body: const Center(
        child: Text('Aqui ficarão as avaliações'),
      ),
    );
  }
}
