import 'package:flutter/material.dart';
import '../models/local.dart';
import '../widgets/barra_acoes.dart';
import '../widgets/cabecalho_local.dart';
import '../widgets/secao_pessoas.dart';
import 'tela_avaliacoes.dart';

class TelaViagens extends StatefulWidget {
  const TelaViagens({super.key});

  @override
  State<TelaViagens> createState() => _TelaViagensState();
}

class _TelaViagensState extends State<TelaViagens> {
  static const Local _coliseu = Local(
    cidade: 'Roma',
    nome: 'Coliseu',
    imagemUrl:
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQxT2NyrMUKn2bTRZ3SaCIfVQ3iYNEscJpFcrPw5fNikjpUIXA9NuBklHL8&s=10',
    descricao: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. '
        'Fusce id diam id libero ultricies pulvinar. In non lacus, sagittis '
        'eu libero et, venenatis lacinia nulla. Etiam eget purus leo. Nam '
        'consectetur ornare est eu lobortis. Morbi eu augue eu lectus '
        'condimentum vestibulum. Etiam id nibh luctus, porttitor arcu et, '
        'porttitor purus. Pellentesque vulputate quis nibh ut rutrum viverra.',
  );

  bool _queroIr = false;
  bool _jaFui = false;

  void _mostrarMensagem(String texto) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(texto)),
    );
  }

  void _abrirAvaliacoes() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const TelaAvaliacoes(local: _coliseu),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Viagens')),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const CabecalhoLocal(local: _coliseu),
            BarraAcoes(
              queroIr: _queroIr,
              jaFui: _jaFui,
              onQueroIr: () => setState(() => _queroIr = !_queroIr),
              onJaFui: () => setState(() => _jaFui = !_jaFui),
              onCompartilhar: () => _mostrarMensagem('Compartilhar em breve'),
              onAvaliacoes: _abrirAvaliacoes,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Text(_coliseu.descricao, textAlign: TextAlign.justify),
            ),
            SecaoPessoas(
              onFiltrar: () => _mostrarMensagem('Filtro em breve'),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
